package io.github.qqlocaltranslator;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

final class TranslationCache extends SQLiteOpenHelper {
    private static final String DB = "translation_cache.db";
    private static final int VERSION = 1;

    TranslationCache(Context context) {
        super(context, DB, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE cache (k TEXT PRIMARY KEY, source TEXT, target TEXT, original TEXT, translated TEXT, updated INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS cache");
        onCreate(db);
    }

    String get(String source, String target, String original) {
        String k = key(source, target, original);
        try (Cursor c = getReadableDatabase().rawQuery("SELECT translated FROM cache WHERE k=?", new String[]{k})) {
            return c.moveToFirst() ? c.getString(0) : null;
        }
    }

    void put(String source, String target, String original, String translated) {
        getWritableDatabase().execSQL(
                "INSERT OR REPLACE INTO cache(k,source,target,original,translated,updated) VALUES(?,?,?,?,?,?)",
                new Object[]{key(source, target, original), source, target, original, translated, System.currentTimeMillis()}
        );
    }

    private String key(String source, String target, String original) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] b = md.digest((source + "\u0000" + target + "\u0000" + original).getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte x : b) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (Exception e) {
            return Integer.toHexString((source + target + original).hashCode());
        }
    }
}
