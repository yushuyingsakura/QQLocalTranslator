package io.github.qqlocaltranslator;

import android.app.Activity;
import android.app.Application;
import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.view.View;
import android.view.ViewParent;
import android.widget.EditText;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.util.Locale;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class QqHook implements IXposedHookLoadPackage {

    private static final String QQ = "com.tencent.mobileqq";
    private static final String MODULE = "io.github.qqlocaltranslator";
    private static final String MARKER = "\n译 · ";

    private static final AtomicLong IDS = new AtomicLong(1);
    private static final Map<Long, Pending> PENDING = new ConcurrentHashMap<>();
    private static final Map<TextView, String> LAST_REQUESTED = java.util.Collections.synchronizedMap(new WeakHashMap<>());
    private static final ThreadLocal<Boolean> INTERNAL_SET = new ThreadLocal<>();

    private static volatile Context qqContext;
    private static volatile Messenger service;
    private static volatile boolean binding;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private static final Messenger REPLY = new Messenger(new Handler(Looper.getMainLooper(), msg -> {
        if (msg.what != Protocol.MSG_RESULT) return false;
        Bundle b = msg.getData();
        long id = b.getLong(Protocol.K_ID, -1L);
        Pending p = PENDING.remove(id);
        if (p == null) return true;
        String translated = b.getString(Protocol.K_TRANSLATION);
        if (translated == null || translated.trim().isEmpty()) return true;
        TextView tv = p.view.get();
        if (tv == null || !tv.isAttachedToWindow()) return true;
        String now = tv.getText() == null ? "" : tv.getText().toString();
        if (!now.equals(p.original)) return true; // RecyclerView cell has been reused.
        applyTranslation(tv, p.original, translated, b.getString(Protocol.K_SOURCE), b.getString(Protocol.K_TARGET));
        return true;
    }));

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!QQ.equals(lpparam.packageName)) return;
        if (lpparam.processName != null && !QQ.equals(lpparam.processName)) return;

        XposedHelpers.findAndHookMethod(Application.class, "attach", Context.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                qqContext = (Context) param.args[0];
                bindTranslator();
            }
        });

        XposedBridge.hookAllMethods(TextView.class, "setText", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                if (Boolean.TRUE.equals(INTERNAL_SET.get())) return;
                if (!(param.thisObject instanceof TextView)) return;
                TextView tv = (TextView) param.thisObject;
                if (tv instanceof EditText) return;
                CharSequence cs = tv.getText();
                if (cs == null) return;
                String text = cs.toString().trim();
                if (!isCandidate(tv, text)) return;
                requestTranslation(tv, text);
            }
        });
    }

    private static boolean isCandidate(TextView tv, String text) {
        if (text.length() < 2 || text.length() > 1200) return false;
        if (text.contains(MARKER)) return false;
        if (text.startsWith("http://") || text.startsWith("https://")) return false;
        if (text.matches("^[\\p{N}\\p{Punct}\\s]+$")) return false;
        if (!looksLikeChatArea(tv)) return false;
        String last = LAST_REQUESTED.get(tv);
        if (text.equals(last)) return false;
        LAST_REQUESTED.put(tv, text);
        return true;
    }

    private static boolean looksLikeChatArea(TextView tv) {
        Activity a = unwrapActivity(tv.getContext());
        if (a != null) {
            String n = a.getClass().getName().toLowerCase(Locale.ROOT);
            if (n.contains("aio") || n.contains("chat")) return true;
        }

        ViewParent p = tv.getParent();
        for (int depth = 0; p != null && depth < 9; depth++, p = p.getParent()) {
            String n = p.getClass().getName().toLowerCase(Locale.ROOT);
            if (n.contains("aio") || n.contains("chat") || n.contains("message") || n.contains("msg") || n.contains("bubble")) {
                return true;
            }
            if (p instanceof View) {
                View v = (View) p;
                int id = v.getId();
                if (id != View.NO_ID) {
                    try {
                        String entry = v.getResources().getResourceEntryName(id).toLowerCase(Locale.ROOT);
                        if (entry.contains("aio") || entry.contains("chat") || entry.contains("msg") || entry.contains("bubble")) {
                            return true;
                        }
                    } catch (Throwable ignored) {
                    }
                }
            }
        }
        return false;
    }

    private static Activity unwrapActivity(Context c) {
        while (c instanceof ContextWrapper) {
            if (c instanceof Activity) return (Activity) c;
            Context next = ((ContextWrapper) c).getBaseContext();
            if (next == c) break;
            c = next;
        }
        return null;
    }

    private static void requestTranslation(TextView tv, String text) {
        Messenger s = service;
        if (s == null) {
            bindTranslator();
            return;
        }
        long id = IDS.getAndIncrement();
        PENDING.put(id, new Pending(tv, text));
        Message m = Message.obtain(null, Protocol.MSG_TRANSLATE);
        Bundle b = new Bundle();
        b.putLong(Protocol.K_ID, id);
        b.putString(Protocol.K_TEXT, text);
        m.setData(b);
        m.replyTo = REPLY;
        try {
            s.send(m);
        } catch (RemoteException e) {
            PENDING.remove(id);
            service = null;
            bindTranslator();
        }
    }

    private static synchronized void bindTranslator() {
        if (qqContext == null || service != null || binding) return;
        binding = true;
        try {
            Intent intent = new Intent();
            intent.setComponent(new ComponentName(MODULE, MODULE + ".TranslationService"));
            boolean ok = qqContext.bindService(intent, CONNECTION, Context.BIND_AUTO_CREATE);
            if (!ok) binding = false;
        } catch (Throwable t) {
            binding = false;
            XposedBridge.log("QQLocalTranslator: bind failed: " + t);
        }
    }

    private static final ServiceConnection CONNECTION = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            service = new Messenger(binder);
            binding = false;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            service = null;
            binding = false;
        }
    };

    private static void applyTranslation(TextView tv, String original, String translated, String source, String target) {
        String src = label(source);
        String dst = label(target);
        String header = "译 · " + src + " → " + dst + "\n";
        SpannableStringBuilder out = new SpannableStringBuilder(original);
        out.append("\n");
        int start = out.length();
        out.append(header).append(translated);
        int end = out.length();

        out.setSpan(new RelativeSizeSpan(0.84f), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        int base = tv.getCurrentTextColor();
        int muted = Color.argb(185, Color.red(base), Color.green(base), Color.blue(base));
        out.setSpan(new ForegroundColorSpan(muted), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        try {
            INTERNAL_SET.set(true);
            tv.setText(out, TextView.BufferType.SPANNABLE);
        } finally {
            INTERNAL_SET.remove();
        }
    }

    private static String label(String code) {
        if (code == null) return "自动";
        switch (code) {
            case "zh": return "中文";
            case "en": return "英语";
            case "ja": return "日语";
            case "ko": return "韩语";
            case "fr": return "法语";
            case "de": return "德语";
            case "es": return "西语";
            case "ru": return "俄语";
            case "it": return "意语";
            case "pt": return "葡语";
            default: return code;
        }
    }

    private static final class Pending {
        final WeakReference<TextView> view;
        final String original;

        Pending(TextView view, String original) {
            this.view = new WeakReference<>(view);
            this.original = original;
        }
    }
}
