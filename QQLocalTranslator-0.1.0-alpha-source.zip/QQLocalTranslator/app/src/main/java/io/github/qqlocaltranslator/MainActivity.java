package io.github.qqlocaltranslator;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.LinkedHashMap;
import java.util.Map;

public class MainActivity extends Activity {

    public static final String PREFS = "translator_settings";
    public static final String KEY_ENABLED = "enabled";
    public static final String KEY_TARGET = "target";
    public static final String KEY_WIFI_ONLY = "wifi_only";

    private final LinkedHashMap<String, String> languages = new LinkedHashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        languages.put("中文（简体）", "zh");
        languages.put("English", "en");
        languages.put("日本語", "ja");
        languages.put("한국어", "ko");
        languages.put("Français", "fr");
        languages.put("Deutsch", "de");
        languages.put("Español", "es");
        languages.put("Русский", "ru");
        languages.put("Italiano", "it");
        languages.put("Português", "pt");

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = dp(20);
        root.setPadding(p, p, p, p);

        TextView title = new TextView(this);
        title.setText("QQ 本地自动翻译");
        title.setTextSize(24);
        root.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("方案 B：不向聊天发送任何翻译消息，只修改你手机上的显示。\n首次遇到某种语言时，ML Kit 可能需要下载对应翻译模型。");
        subtitle.setTextSize(15);
        subtitle.setPadding(0, dp(10), 0, dp(18));
        root.addView(subtitle, matchWrap());

        Switch enabled = new Switch(this);
        enabled.setText("启用自动翻译");
        enabled.setChecked(prefs.getBoolean(KEY_ENABLED, true));
        root.addView(enabled, matchWrap());

        TextView targetLabel = new TextView(this);
        targetLabel.setText("目标语言");
        targetLabel.setPadding(0, dp(18), 0, dp(6));
        root.addView(targetLabel, matchWrap());

        Spinner spinner = new Spinner(this);
        String[] names = languages.keySet().toArray(new String[0]);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, names);
        spinner.setAdapter(adapter);
        String currentTarget = prefs.getString(KEY_TARGET, "zh");
        int selected = 0;
        int i = 0;
        for (Map.Entry<String, String> e : languages.entrySet()) {
            if (e.getValue().equals(currentTarget)) selected = i;
            i++;
        }
        spinner.setSelection(selected);
        root.addView(spinner, matchWrap());

        CheckBox wifiOnly = new CheckBox(this);
        wifiOnly.setText("仅在 Wi-Fi 下下载新的语言模型（推荐）");
        wifiOnly.setChecked(prefs.getBoolean(KEY_WIFI_ONLY, true));
        wifiOnly.setPadding(0, dp(14), 0, 0);
        root.addView(wifiOnly, matchWrap());

        TextView note = new TextView(this);
        note.setText("显示效果：\n原文\n译 · 日语 → 中文\n译文\n\n翻译在设备本地完成；模块不会调用 QQ 的发送消息接口。若 QQ 更新后气泡结构改变，可能需要更新适配。\n\n安装后请在 LSPosed 中仅勾选 QQ 作用域，然后强制停止并重新打开 QQ。");
        note.setTextSize(14);
        note.setPadding(0, dp(18), 0, dp(18));
        root.addView(note, matchWrap());

        Button save = new Button(this);
        save.setText("保存设置");
        save.setOnClickListener(v -> {
            String selectedName = (String) spinner.getSelectedItem();
            String code = languages.get(selectedName);
            prefs.edit()
                    .putBoolean(KEY_ENABLED, enabled.isChecked())
                    .putString(KEY_TARGET, code == null ? "zh" : code)
                    .putBoolean(KEY_WIFI_ONLY, wifiOnly.isChecked())
                    .apply();
            Toast.makeText(this, "已保存。重新打开 QQ 后生效。", Toast.LENGTH_SHORT).show();
        });
        root.addView(save, matchWrap());

        setContentView(root);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
