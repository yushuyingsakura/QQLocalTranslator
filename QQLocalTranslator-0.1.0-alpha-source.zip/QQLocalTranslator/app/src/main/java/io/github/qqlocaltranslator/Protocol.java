package io.github.qqlocaltranslator;

final class Protocol {
    private Protocol() {}

    static final int MSG_TRANSLATE = 1;
    static final int MSG_RESULT = 2;

    static final String K_ID = "id";
    static final String K_TEXT = "text";
    static final String K_TRANSLATION = "translation";
    static final String K_SOURCE = "source";
    static final String K_TARGET = "target";
    static final String K_ERROR = "error";
}
