package io.github.qqlocaltranslator;

import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.languageid.LanguageIdentification;
import com.google.mlkit.nl.languageid.LanguageIdentifier;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class TranslationService extends Service {

    private final Map<String, Translator> translators = new ConcurrentHashMap<>();
    private LanguageIdentifier languageIdentifier;
    private TranslationCache cache;
    private Messenger messenger;

    @Override
    public void onCreate() {
        super.onCreate();
        languageIdentifier = LanguageIdentification.getClient();
        cache = new TranslationCache(this);
        messenger = new Messenger(new android.os.Handler(getMainLooper(), msg -> {
            if (msg.what == Protocol.MSG_TRANSLATE) {
                if (isAllowedSender(msg.sendingUid)) handleTranslate(msg);
                return true;
            }
            return false;
        }));
    }

    @Override
    public IBinder onBind(Intent intent) {
        return messenger.getBinder();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try { languageIdentifier.close(); } catch (Exception ignored) {}
        for (Translator t : translators.values()) {
            try { t.close(); } catch (Exception ignored) {}
        }
        translators.clear();
        try { cache.close(); } catch (Exception ignored) {}
    }

    private boolean isAllowedSender(int uid) {
        if (uid == android.os.Process.myUid()) return true;
        String[] packages = getPackageManager().getPackagesForUid(uid);
        if (packages == null) return false;
        for (String p : packages) {
            if ("com.tencent.mobileqq".equals(p)) return true;
        }
        return false;
    }

    private void handleTranslate(Message request) {
        Bundle data = request.getData();
        long id = data.getLong(Protocol.K_ID, -1L);
        String text = data.getString(Protocol.K_TEXT, "").trim();
        Messenger reply = request.replyTo;
        if (reply == null || id < 0 || text.length() < 2 || text.length() > 1200) return;

        SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        String target = prefs.getString(MainActivity.KEY_TARGET, "zh");
        if (!prefs.getBoolean(MainActivity.KEY_ENABLED, true)) {
            send(reply, id, null, null, target, "disabled");
            return;
        }

        languageIdentifier.identifyLanguage(text)
                .addOnSuccessListener(sourceTag -> {
                    if (sourceTag == null || "und".equals(sourceTag)) {
                        send(reply, id, null, null, target, "undetermined");
                        return;
                    }
                    String source = TranslateLanguage.fromLanguageTag(sourceTag);
                    String normalizedTarget = TranslateLanguage.fromLanguageTag(target);
                    if (source == null || normalizedTarget == null) {
                        send(reply, id, null, sourceTag, target, "unsupported_language");
                        return;
                    }
                    if (source.equals(normalizedTarget)) {
                        send(reply, id, null, source, normalizedTarget, null);
                        return;
                    }

                    String cached = cache.get(source, normalizedTarget, text);
                    if (cached != null) {
                        send(reply, id, cached, source, normalizedTarget, null);
                        return;
                    }

                    Translator translator = translatorFor(source, normalizedTarget);
                    DownloadConditions.Builder b = new DownloadConditions.Builder();
                    if (prefs.getBoolean(MainActivity.KEY_WIFI_ONLY, true)) b.requireWifi();
                    translator.downloadModelIfNeeded(b.build())
                            .addOnSuccessListener(v -> translator.translate(text)
                                    .addOnSuccessListener(translated -> {
                                        if (translated != null && !translated.trim().isEmpty()) {
                                            cache.put(source, normalizedTarget, text, translated);
                                            send(reply, id, translated, source, normalizedTarget, null);
                                        } else {
                                            send(reply, id, null, source, normalizedTarget, "empty_result");
                                        }
                                    })
                                    .addOnFailureListener(e -> send(reply, id, null, source, normalizedTarget, "translate_failed")))
                            .addOnFailureListener(e -> send(reply, id, null, source, normalizedTarget, "model_download_failed"));
                })
                .addOnFailureListener(e -> send(reply, id, null, null, target, "language_id_failed"));
    }

    private Translator translatorFor(String source, String target) {
        String k = source + ">" + target;
        Translator existing = translators.get(k);
        if (existing != null) return existing;
        Translator created = Translation.getClient(new TranslatorOptions.Builder()
                .setSourceLanguage(source)
                .setTargetLanguage(target)
                .build());
        Translator race = translators.putIfAbsent(k, created);
        if (race != null) {
            created.close();
            return race;
        }
        return created;
    }

    private void send(Messenger reply, long id, String translation, String source, String target, String error) {
        Message result = Message.obtain(null, Protocol.MSG_RESULT);
        Bundle b = new Bundle();
        b.putLong(Protocol.K_ID, id);
        if (translation != null) b.putString(Protocol.K_TRANSLATION, translation);
        if (source != null) b.putString(Protocol.K_SOURCE, source);
        if (target != null) b.putString(Protocol.K_TARGET, target);
        if (error != null) b.putString(Protocol.K_ERROR, error);
        result.setData(b);
        try {
            reply.send(result);
        } catch (RemoteException ignored) {
        }
    }
}
