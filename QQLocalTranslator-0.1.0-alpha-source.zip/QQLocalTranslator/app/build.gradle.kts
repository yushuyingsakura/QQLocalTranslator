plugins {
    id("com.android.application")
}

android {
    namespace = "io.github.qqlocaltranslator"
    compileSdk = 35

    defaultConfig {
        applicationId = "io.github.qqlocaltranslator"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0-alpha"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    // Xposed API is supplied by LSPosed at runtime. Never package it into the APK.
    compileOnly("de.robv.android.xposed:api:82")

    // On-device language detection + translation.
    implementation("com.google.mlkit:language-id:17.0.6")
    implementation("com.google.mlkit:translate:17.0.3")
}
