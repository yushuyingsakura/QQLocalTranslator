# Alpha build: no shrinking. Keep this file for future release builds.
