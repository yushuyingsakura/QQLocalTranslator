# QQ 本地自动翻译（Android / LSPosed）

> 0.1.0-alpha：方案 B 原型。译文只显示在你自己的 QQ 界面，不会向群聊/私聊发送任何翻译消息。

## 设计目标

- 仅作用于 Android QQ (`com.tencent.mobileqq`)
- 自动识别消息语言
- 将外语翻译到指定目标语言（默认简体中文）
- 保留原文，在原消息 TextView 下方追加：`译 · 日语 → 中文` + 译文
- 翻译由 Google ML Kit 在设备端执行
- SQLite 本地缓存，重复文本无需重新翻译
- 不 Hook QQ 的发送消息接口

## 技术结构

1. `QqHook` 是 Xposed/LSPosed 入口。
2. 它只 Hook QQ 主进程中的 `TextView.setText()`，筛选疑似 AIO/Chat/Message/Bubble 视图。
3. 文本通过 Android `Messenger` 发到本模块自己的 `TranslationService`。
4. `TranslationService` 使用 ML Kit 做语言识别和本地翻译。
5. 翻译完成后，把译文回传给 QQ 进程，并在原 TextView 下方本地追加译文。
6. QQ 网络层和发消息接口完全不参与。

## 构建

推荐 Android Studio（JDK 17）。打开项目后直接构建 APK：

```text
Build > Build APK(s)
```

或本机有 Gradle Wrapper 时：

```bash
./gradlew :app:assembleDebug
```

生成位置通常为：

```text
app/build/outputs/apk/debug/app-debug.apk
```

## 安装

1. 手机需要可用的 LSPosed/Xposed 环境。
2. 安装本模块 APK。
3. 打开模块 App，选择目标语言，默认开启“仅 Wi-Fi 下载语言模型”。
4. 在 LSPosed 管理器中启用 **QQ 本地翻译**。
5. 作用域只勾选 **QQ (`com.tencent.mobileqq`)**。
6. 强制停止 QQ，再重新打开。
7. 打开含外语文本的聊天。首次遇到一种语言时，模型可能需要先下载，因此第一次不会立即出现译文；下载成功后再次刷新/收到消息即可。

## 当前 Alpha 版限制

QQ 的聊天 UI 会随版本变化。本版本使用通用的 View 层筛选（AIO/Chat/Message/Bubble）而不是写死 QQ 内部混淆类，因此更耐版本变化，但不能保证所有 QQ 版本都能正确识别气泡。

如果出现以下情况，需要针对你的 QQ 版本做一次适配：

- 聊天气泡没有翻译
- 会话列表/其它页面也被翻译
- QQ 使用自绘文本而不是 `TextView`
- 部分复合消息（引用、卡片、富文本）不显示译文

这版只处理文本 View，不处理图片 OCR、语音、文件、表情和卡片内容。

## 隐私

聊天文本不会发到第三方翻译 API。语言识别与翻译逻辑由 ML Kit 在设备上执行；首次使用某个语言对时需要联网下载语言模型。

## 风险提示

第三方 Hook/注入会改变 QQ 客户端运行时行为。即使本模块不改发消息网络逻辑，也无法保证 QQ 不会把模块环境视为异常。建议只在你能接受风险的账号和设备上测试。
